from django.urls import path
from .views import * 

urlpatterns = [
    path('',book_list,name="book_list"),
    path('book/new/',create_book,name='create_book'),
    path('book/<int:pk>/edit/',update_book,name="update_book"),
    path('book/<int:pk>/delete/',delete_book,name="delete_book")
    ]
