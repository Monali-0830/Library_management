from django.shortcuts import render,get_object_or_404,redirect
from .models import Book
from .forms import Bookform

# Create your views here.
#create book

def create_book(request):
    if request.method == "POST":
        form = Bookform(request.POST)
        if form.is_valid():
            form.save()
            return redirect('book_list')
    else:
        form = Bookform()
    return render(request,'library/book_form.html',{'form':form})            
    
#Viewing book 


def book_list(request):
    book= Book.objects.all()
    return render(request,'library/book_list.html',{'book':book})


#update Book

def update_book(request,pk):
    book = get_object_or_404(Book,pk=pk)
    if request.method == "POST":
        form = Bookform(request.POST,instance=book)
        if form.is_valid():
            form.save()
            return redirect('book_list')
    else:
        form = Bookform(instance=book)    
    return render(request,'library/book_form.html',{'form':form})  


def delete_book(request,pk):
    book = get_object_or_404(Book,pk=pk)
    if request.method == "POST":
        book.delete()
        return redirect('book_list')
    else:
        return render(request,'library/confirm_book_delete.html',{'book':book})
    
    